from hearthbreaker.cards.weapons.hunter import (
    EaglehornBow,
    GladiatorsLongbow,
)

from hearthbreaker.cards.weapons.paladin import (
    LightsJustice,
    SwordOfJustice,
    TruesilverChampion,
)

from hearthbreaker.cards.weapons.rogue import (
    AssassinsBlade,
    PerditionsBlade,
)

from hearthbreaker.cards.weapons.shaman import (
    Doomhammer,
    StormforgedAxe,
)

from hearthbreaker.cards.weapons.warrior import (
    FieryWarAxe,
    ArcaniteReaper,
    Gorehowl,
    DeathsBite,
)
